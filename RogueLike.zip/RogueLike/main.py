# Imports
import random
import sys
from pathlib import Path
import pygame

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
WALL_THICKNESS = 40
DOOR_SIZE = 90

COLOR_BG = (26, 22, 20)
COLOR_FLOOR_A = (74, 68, 62)
COLOR_FLOOR_B = (68, 62, 56)
COLOR_WALL = (40, 36, 33)
COLOR_WALL_EDGE = (20, 18, 16)
COLOR_DOOR_LOCKED = (40, 36, 33)
COLOR_DOOR_OPEN = (92, 58, 30)
COLOR_DOOR_GOLD = (255, 215, 0)
COLOR_HEART_FULL = (200, 40, 40)
COLOR_HEART_EMPTY = (60, 40, 40)
COLOR_TEXT = (225, 220, 205)
COLOR_TEXT_DIM = (150, 145, 135)
COLOR_HITBOX = (255, 80, 80)

PLAYER_HITBOX = (28, 38)
ENEMY_HITBOXES = (26, 32)
BOSS_HITBOX = (76, 100)
ENEMY_SPRITE_SIZE = 56
BOSS_SPRITE_SIZE = 112
PLAYER_PROJECTILE_SIZE = 14
ENEMY_PROJECTILE_SIZE = 18
BOSS_PROJECTILE_SIZE = 22
ENEMY_SPEED_UNIT = 50


def clamp(value, low, heigh):
    return max(low, min(heigh, value))

def load_image(path: Path, size: tuple[int, int]):
    if not path.is_file():
        raise FileNotFoundError(f'Missing required image: {path}')
    return pygame.transform.scale(pygame.image.load(path).convert_alpha(), size)

def flash_image(image: pygame.Surface, colour: tuple[int, int, int]):
    flashed = image.copy()
    blend = pygame.BLEND_RGB_ADD if colour == (255, 255, 255) else pygame.BLEND_RGB_MULT
    flashed.fill(colour, special_flags = blend)
    return flashed


# Classes

# Projectiles
class Projectile(pygame.sprite.Sprite):
    def __init__(self, x, y, dx, dy, speed, size, damage, image):
        super().__init__()
        self.rect = pygame.FRect(0, 0, size, size)
        self.rect.center = (x, y)
        direction = pygame.Vector2(dx, dy)
        if direction.length_squared() == 0:
            direction = pygame.Vector2(0, -1)
        self.direction = direction.normalize()
        self.vx = self.direction.x * speed
        self.vy = self.direction.y * speed
        self.damage = damage
        
        angle = self.direction.angle_to(pygame.Vector2(0, -1))
        self.image = pygame.transform.rotate(image, angle)
        
    def update(self, dt, bounds):
        self.rect.x += self.vx * dt
        self.rect.y += self.vy * dt
        if not bounds.contains(self.rect):
            self.kill()
    
    def draw(self, screen):
        screen.blit(self.image, self.image.get_rect(center = self.rect.center))

# Player
class Player(pygame.sprite.Sprite):
    SIZE = 68
    SPEED = 230
    SHOT_COOLDOWN = 0.28
    HURT_COOLDOWN = 0.9
    
    def __init__(self, x, y, image):
        super().__init__()
        self.rect = pygame.FRect(0, 0, *PLAYER_HITBOX)
        self.rect.center = (x, y)
        self.image = image['player']
        self.projectile_image = image['sword']
        self.max_hp = 5
        self.hp = self.max_hp
        self.shot_timer = 0.0
        self.hurt_timer = 0.0
        self.projectiles = pygame.sprite.Group()
        self.facing = pygame.Vector2(0, -1)
        
        self.abilities = []
    
    def gain_ability(self, ability_name):
        self.abilities.append(ability_name)
        
        if ability_name == "More_speed":
            self.SPEED += 80 
            
        elif ability_name == "More_attack_speed":
            self.SHOT_COOLDOWN = max(0.1, self.SHOT_COOLDOWN - 0.08) 
            
        elif ability_name == "More_health":
            self.max_hp += 1
            self.hp += 1
        
    def handle_inputs(self, dt, keys):
        move = pygame.Vector2(
            keys[pygame.K_d] - keys[pygame.K_a],
            keys[pygame.K_s] - keys[pygame.K_w]
        )
        
        if move.length_squared() > 0:
            move = move.normalize()
            self.rect.x += move.x * self.SPEED * dt
            self.rect.y += move.y * self.SPEED * dt
        
        aim = pygame.Vector2(
            keys[pygame.K_RIGHT] - keys[pygame.K_LEFT],
            keys[pygame.K_UP] - keys[pygame.K_DOWN]
        )
        
        if aim.length_squared() > 0:
            self.facing = aim.normalize()
            if self.shot_timer <= 0:
                self.shoot()
    
    def shoot(self):
        self.projectiles.add(Projectile(
            self.rect.centerx, self.rect.centery, self.facing.x, self.facing.y, 460,
            PLAYER_PROJECTILE_SIZE, 1, self.projectile_image
        ))
        self.shot_timer = self.SHOT_COOLDOWN
    
    def take_damage(self, amount):
        if self.hurt_timer <= 0:
            self.hp = clamp(self.hp - amount, 0, self.max_hp)
            self.hurt_timer = self.HURT_COOLDOWN
    
    def update(self, dt, keys, bounds):
        self.shot_timer = max(0.0, self.shot_timer - dt)
        self.hurt_timer = max(0.0, self.hurt_timer - dt)
        self.handle_inputs(dt, keys)
        self.projectiles.update(dt, bounds.inflate(200, 200))
    
    def draw(self, screen):
        flashing = self.hurt_timer > 0 and int(self.hurt_timer * 12) % 2 == 0
        image = flash_image(self.image, (255, 130, 130)) if flashing else self.image
        screen.blit(image, image.get_rect(center=self.rect.center))
        for projectile in self.projectiles:
            projectile.draw(screen)

# Enemies
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, size, hp, contact_damage, speed, image, hitbox):
        super().__init__()
        self.rect = pygame.FRect(0, 0, *hitbox)
        self.rect.center = (x, y)
        self.max_hp = hp
        self.hp = self.max_hp
        self.speed = speed
        self.contact_damage = contact_damage
        self.image = image
        self.hit_flash = 0.0
    
    def chase(self, dt, target_pos, bounds):
        direction = pygame.Vector2(target_pos) - pygame.Vector2(self.rect.center)
        if direction.length_squared() > 1:
            direction = direction.normalize()
            self.rect.x += direction.x * self.speed * dt
            self.rect.y += direction.y * self.speed * dt
            self.rect.clamp_ip(bounds)
    
    def take_damage(self, amount):
        self.hp -= amount
        self.hit_flash = 0.12
        if self.hp <= 0:
            self.kill()
    
    def update(self, dt, player_pos, bounds):
        self.hit_flash = max(0.0, self.hit_flash - dt)
        self.chase(dt, player_pos, bounds)
    
    def draw(self, screen):
        image = flash_image(self.image, (255, 255, 255)) if self.hit_flash > 0 else self.image
        screen.blit(image, image.get_rect(center=self.rect.center))
        self.draw_hp_bar(screen)
    
    def draw_hp_bar(self, screen):
        if self.hp >= self.max_hp:
            return
        back = pygame.Rect(int(self.rect.left), int(self.rect.top) - 8, int(self.rect.width), 4)
        pygame.draw.rect(screen, (20, 20, 20), back)
        front = pygame.Rect(back.left, back.top, int(back.width * self.hp / self.max_hp), 4)
        pygame.draw.rect(screen, (200, 40, 40), front)

class Goblin(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, ENEMY_SPRITE_SIZE, 2, 1, 150, image['goblin'], ENEMY_HITBOXES)

class Skeleton(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, ENEMY_SPRITE_SIZE, 4, 1, 105, image['skeleton'], ENEMY_HITBOXES)

class Wizard(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, ENEMY_SPRITE_SIZE, 3, 1, 120, image['wizard'], ENEMY_HITBOXES)
        self.fireball_image = image['fireball']
        self.fireball_timer = 2.0
        self.fireballs = pygame.sprite.Group()
        
    def update(self, dt, player_pos, bounds):
        super().update(dt, player_pos, bounds)
        self.fireball_timer -= dt
        if self.fireball_timer <= 0:
            self.fireball_timer = 2.1
            direction = pygame.Vector2(player_pos) - pygame.Vector2(self.rect.center)
            self.fireballs.add(Projectile(self.rect.centerx, self.rect.centery,
                                          direction.x, direction.y, 240, ENEMY_PROJECTILE_SIZE, 1,
                                          self.fireball_image))
        self.fireballs.update(dt, bounds.inflate(200, 200))
        
    def draw(self, screen):
        super().draw(screen)
        for fireball in self.fireballs:
            fireball.draw(screen)

class Boss(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, BOSS_SPRITE_SIZE, 26, 2, 95, image["boss"], BOSS_HITBOX)
        self.bolt_image = image["bolt"]
        self.bolt_timer = 1.5
        self.bolts = pygame.sprite.Group()

    def update(self, dt, player_pos, bounds):
        super().update(dt, player_pos, bounds)
        self.bolt_timer -= dt
        if self.bolt_timer <= 0:
            self.bolt_timer = 1.6
            direction = pygame.Vector2(player_pos) - pygame.Vector2(self.rect.center)
            self.bolts.add(Projectile(self.rect.centerx, self.rect.centery,
                                      direction.x, direction.y, 240, BOSS_PROJECTILE_SIZE, 1,
                                      self.bolt_image))
        self.bolts.update(dt, bounds.inflate(200, 200))

    def draw(self, screen):
        super().draw(screen)
        for bolt in self.bolts:
            bolt.draw(screen)


class Room:
    def __init__(self, name, enemy_specs, connections, room_type="normal", images = None):
        self.name = name
        self.room_type = room_type
        self.connections = connections
        self.bounds = pygame.FRect(WALL_THICKNESS, WALL_THICKNESS, WIDTH - 2 * WALL_THICKNESS,
                                   HEIGHT - 2 * WALL_THICKNESS)
        self.enemies = pygame.sprite.Group(*(enemy_type(x, y, images)for enemy_type, x, y in enemy_specs))
        self.cleared = not self.enemies
        self.entered = False
        self.pedestals = pygame.sprite.Group()
        self.choices_spawned = False
        
    @property
    def door_rects(self):
        return {
            'top': pygame.Rect(WIDTH // 2 - DOOR_SIZE // 2, 0, DOOR_SIZE, WALL_THICKNESS),
            'bottom': pygame.Rect(WIDTH // 2 - DOOR_SIZE // 2, HEIGHT - WALL_THICKNESS, DOOR_SIZE, WALL_THICKNESS),
            'left': pygame.Rect(0, HEIGHT // 2 - DOOR_SIZE // 2, WALL_THICKNESS, DOOR_SIZE),
            'right': pygame.Rect(WIDTH - WALL_THICKNESS, HEIGHT // 2 - DOOR_SIZE // 2, WALL_THICKNESS, DOOR_SIZE)
        }
    
    def update(self, player, images):
        if not self.cleared and not self.enemies:
            self.cleared = True

        if self.room_type == "treasure" and not self.choices_spawned:
            self.spawn_abilities(images)
            self.choices_spawned = True

        self.handle_pedestal_selection(player)
    
    def spawn_abilities(self, images):
        center_y = HEIGHT // 2
        x_positions = [WIDTH // 2 - 100, WIDTH // 2, WIDTH // 2 + 100]
        
        ability_pool = ["More_speed", "More_attack_speed", "More_health"]
        selected_abilities = random.sample(ability_pool, 3)

        for i, x_pos in enumerate(x_positions):
            ability_name = selected_abilities[i]
            pedestal = AbilityPedestal(x_pos, center_y, ability_name, images)
            self.pedestals.add(pedestal)
    
    def handle_pedestal_selection(self, player):
        hit_pedestals = pygame.sprite.spritecollide(player, self.pedestals, False)
        
        for pedestal in hit_pedestals:
            if not pedestal.is_empty:
                player.gain_ability(pedestal.ability_name)
                print(f"Player selected: {pedestal.ability_name}!")
                
                self.pedestals.empty() 
                break
    
    def draw(self, screen):
        tile = 40
        for ty in range(int(self.bounds.top), int(self.bounds.bottom), tile):
            for tx in range(int(self.bounds.left), int(self.bounds.right), tile):
                color = COLOR_FLOOR_A if (tx // tile + ty // tile) % 2 == 0 else COLOR_FLOOR_B
                pygame.draw.rect(screen, color, (tx, ty, tile, tile))
                
        for pedestal in self.pedestals:
            pedestal.draw(screen)

        pygame.draw.rect(screen, COLOR_WALL, (0, 0, WIDTH, WALL_THICKNESS))
        pygame.draw.rect(screen, COLOR_WALL, (0, HEIGHT - WALL_THICKNESS, WIDTH, WALL_THICKNESS))
        pygame.draw.rect(screen, COLOR_WALL, (0, 0, WALL_THICKNESS, HEIGHT))
        pygame.draw.rect(screen, COLOR_WALL, (WIDTH - WALL_THICKNESS, 0, WALL_THICKNESS, HEIGHT))
        pygame.draw.rect(screen, COLOR_WALL_EDGE, (0, 0, WIDTH, HEIGHT), 4)

        for direction, exists in self.connections.items():
            if exists:
                rect = self.door_rects[direction]
                if not self.cleared:
                    color = COLOR_DOOR_LOCKED 
                else:
                    color = COLOR_DOOR_GOLD if self.room_type == "treasure" else COLOR_DOOR_OPEN
                pygame.draw.rect(screen, color, rect)
    
class AbilityPedestal(pygame.sprite.Sprite):
    def __init__(self, x, y, ability_name, images):
        super().__init__()
        self.ability_name = ability_name 
        self.is_empty = False
        
        self.pedestal_image = images["pedestal"]
        self.item_image = images[ability_name]
        
        self.rect = self.pedestal_image.get_rect(center=(x, y))

    def draw(self, screen):
        screen.blit(self.pedestal_image, self.rect)
        
        item_rect = self.item_image.get_rect()
        item_rect.centerx = self.rect.centerx
        item_rect.centery = self.rect.centery - 25  # Offset upwards to simulate floating
        screen.blit(self.item_image, item_rect)

def build_rooms(images):
        return [
            Room(
                name="Room 1", 
                enemy_specs=[], 
                connections={'top': False, 'bottom': False, 'left': False, 'right': True}, 
                room_type="normal", 
                images=images
            ),
            
            Room(
                name="Room 2", 
                enemy_specs=[(Goblin, random.randint(400, 650), random.randint(150, 450)) for _ in range(random.randint(2, 5))], 
                connections={'top': True, 'bottom': False, 'left': True, 'right': True}, 
                room_type="normal", 
                images=images
            ),
            
            Room(
                name="Treasure Room 1",
                enemy_specs=[],
                connections={'top': False, 'bottom': True, 'left': False, 'right': False},
                room_type="treasure",
                images=images
            ),
            
            Room(
                name="Room 3", 
                enemy_specs=[(random.choice((Skeleton, Goblin)), random.randint(400, 650), random.randint(150, 450)) for _ in range(random.randint(3, 6))], 
                connections={'top': False, 'bottom': False, 'left': True, 'right': True}, 
                room_type="normal", 
                images=images
            ),
            
            Room(
                name="Room 4", 
                enemy_specs=[(Wizard, random.randint(400, 650), random.randint(150, 450)) for _ in range(random.randint(2, 4))], 
                connections={'top': True, 'bottom': False, 'left': True, 'right': True}, 
                room_type="normal", 
                images=images
            ),
            
            Room(
                name="Treasure Room 2",
                enemy_specs=[],
                connections={'top': False, 'bottom': True, 'left': False, 'right': False},
                room_type="treasure",
                images=images
            ),
            
            Room(
                name="Boss Room", 
                enemy_specs=[(Boss, WIDTH // 2 + 60, HEIGHT // 2)], 
                connections={'top': False, 'bottom': False, 'left': True, 'right': False}, 
                room_type="boss", 
                images=images
            ),
        ]
        
class GameState:
    TITLE = "title"
    PLAYING = "playing"
    GAME_OVER = "game_over"
    WIN = "win"

class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption('Game')
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.font_big = pygame.font.SysFont("georgia", 52, bold=True)
        self.font_mid = pygame.font.SysFont("georgia", 28, bold=True)
        self.font_small = pygame.font.SysFont("georgia", 18)
        
        asset_dir = Path(__file__).resolve().parent / "assets"
        self.images = {
                    "player": load_image(asset_dir / "player.png", (68, 68)),
                    "goblin": load_image(asset_dir / "goblin.png", (ENEMY_SPRITE_SIZE, ENEMY_SPRITE_SIZE)),
                    "wizard": load_image(asset_dir / "wizard.png", (ENEMY_SPRITE_SIZE, ENEMY_SPRITE_SIZE)),
                    "skeleton": load_image(asset_dir / "skeleton.png", (ENEMY_SPRITE_SIZE, ENEMY_SPRITE_SIZE)),
                    "fireball": load_image(asset_dir / "fireball.png", (ENEMY_PROJECTILE_SIZE, ENEMY_PROJECTILE_SIZE)),
                    "boss": load_image(asset_dir / "boss.png", (BOSS_SPRITE_SIZE, BOSS_SPRITE_SIZE)),
                    "sword": load_image(asset_dir / "sword.png", (PLAYER_PROJECTILE_SIZE, PLAYER_PROJECTILE_SIZE)),
                    "bolt": load_image(asset_dir / "bolt.png", (BOSS_PROJECTILE_SIZE, BOSS_PROJECTILE_SIZE)),
                    "pedestal": load_image(asset_dir / "pedestal.png", (60, 60)),
                    "More_speed": load_image(asset_dir / "More_speed.png", (30, 30)),
                    "More_attack_speed": load_image(asset_dir / "More_attack_speed.png", (30, 30)),
                    "More_health": load_image(asset_dir / "More_health.png", (30, 30)),
                }
        self.menu_image = load_image(asset_dir / "menu_background.png", (WIDTH, HEIGHT))
        self.state = GameState.TITLE
        self.show_hitboxes = False
        self.reset()
        
    def reset(self):
            self.rooms = build_rooms(self.images)
            self.room_index = 0
            self.player = Player(WIDTH // 2, HEIGHT // 2, self.images)
            self.rooms[0].entered = True
        
    @property
    def room(self):
            return self.rooms[self.room_index]

    def clamp_player_to_room(self, room):
            self.player.rect.clamp_ip(room.bounds)
    
    def update_playing(self, dt, keys):
            room = self.room
            self.player.update(dt, keys, room.bounds)
            self.clamp_player_to_room(room)
            room.enemies.update(dt, self.player.rect.center, room.bounds)
            room.update(self.player, self.images)

            for projectile in list(self.player.projectiles):
                enemies = pygame.sprite.spritecollide(projectile, room.enemies, False)
                if enemies:
                    for enemy in enemies:
                        enemy.take_damage(projectile.damage)
                    projectile.kill()
            
            for enemy in room.enemies:
                if self.player.rect.colliderect(enemy.rect):
                    self.player.take_damage(enemy.contact_damage)
                if isinstance(enemy, Boss):
                    for bolt in list(enemy.bolts):
                        if bolt.rect.colliderect(self.player.rect):
                            self.player.take_damage(bolt.damage)
                            bolt.kill()
                
            if self.player.hp <= 0:
                self.state = GameState.GAME_OVER
                
            elif room.name == "Boss Room" and room.cleared and room.entered:
                self.state = GameState.WIN

            elif room.cleared:
                for direction, exists in room.connections.items():
                    if exists:
                        door_rect = room.door_rects[direction]
            
                        if self.player.rect.colliderect(door_rect.inflate(20, 20)):
                            self.go_to_room(direction)
                            break

    def go_to_room(self, direction):
            transitions = {
                (0, "right"): 1, (1, "left"): 0, (1, "top"): 2,
                (1, "right"): 3, (2, "bottom"): 1, (3, "left"): 1,
                (3, "right"): 4, (4, "left"): 3, (4, "top"): 5,
                (4, "right"): 6, (5, "bottom"): 4, (6, "left"): 4,
            }
            next_room = transitions.get((self.room_index, direction))
            if next_room is None:
                return

            self.room_index = next_room
            if direction == "right":
                self.player.rect.left = WALL_THICKNESS + 10
            elif direction == "left":
                self.player.rect.right = WIDTH - WALL_THICKNESS - 10
            elif direction == "top":
                self.player.rect.bottom = HEIGHT - WALL_THICKNESS - 10
            else:
                self.player.rect.top = WALL_THICKNESS + 10
            self.rooms[self.room_index].entered = True
            
    def draw_hud(self, screen, room):
            for index in range(self.player.max_hp):
                color = COLOR_HEART_FULL if index < self.player.hp else COLOR_HEART_EMPTY
                pygame.draw.rect(screen, color, (16 + index * 26, 16, 20, 20), border_radius=5)
            label = self.font_small.render(f"{room.name}  ({self.room_index + 1}/{len(self.rooms)})",
                                            True, COLOR_TEXT_DIM)
            screen.blit(label, (WIDTH - label.get_width() - 16, 16))
            if not room.cleared and room.enemies:
                hint = self.font_small.render("Defeat all enemies to open the door!", True, COLOR_TEXT_DIM)
                screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, 16))
        
    def draw_playing(self, screen):
            self.room.draw(screen)
            for enemy in self.room.enemies:
                enemy.draw(screen)
            self.player.draw(screen)
            if self.show_hitboxes:
                self.draw_hitboxes(screen)
            self.draw_hud(screen, self.room)
        
    def draw_hitboxes(self, screen):
            pygame.draw.rect(screen, COLOR_HITBOX, self.player.rect, 1)
            for projectile in self.player.projectiles:
                pygame.draw.rect(screen, COLOR_HITBOX, projectile.rect, 1)
            for enemy in self.room.enemies:
                pygame.draw.rect(screen, COLOR_HITBOX, enemy.rect, 1)
                if isinstance(enemy, Boss):
                    for bolt in enemy.bolts:
                        pygame.draw.rect(screen, COLOR_HITBOX, bolt.rect, 1)
        
    def draw_overlay(self, screen, headline, subline, color):
            shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 150))
            screen.blit(shade, (0, 0))
            title = self.font_big.render(headline, True, color)
            subtitle = self.font_small.render(subline, True, COLOR_TEXT)
            screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20)))
            screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 32)))
        
    def draw_title(self, screen):
            screen.blit(self.menu_image, (0, 0))
            panel = pygame.Surface((510, 210), pygame.SRCALPHA)
            panel.fill((12, 10, 9, 185))
            panel_rect = panel.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 8))
            screen.blit(panel, panel_rect)
        
            title = self.font_big.render("Game", True, COLOR_TEXT)
            prompt = self.font_mid.render("Press SPACE to start", True, (245, 210, 100))
            controls = self.font_small.render("Move: WASD     Shoot: Arrow Keys", True, COLOR_TEXT)
            screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 70)))
            screen.blit(prompt, prompt.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            screen.blit(controls, controls.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 50)))
        
    def draw(self):
            self.screen.fill(COLOR_BG)
            if self.state == GameState.TITLE:
                self.draw_title(self.screen)
            else:
                self.draw_playing(self.screen)
                if self.state == GameState.GAME_OVER:
                    self.draw_overlay(self.screen, "YOU HAVE DIED", "Press R to try again", (150, 30, 30))
                elif self.state == GameState.WIN:
                    self.draw_overlay(self.screen, "GG You Won!",
                                    "Give us A pls - Press R to play again",
                                    (30, 100, 60))
            pygame.display.flip()

    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        sys.exit()
                    if event.key == pygame.K_SPACE and self.state == GameState.TITLE:
                        self.state = GameState.PLAYING
                    if event.key == pygame.K_r and self.state in (GameState.GAME_OVER, GameState.WIN):
                        self.reset()
                        self.state = GameState.PLAYING
                    if event.key == pygame.K_F3:
                        self.show_hitboxes = not self.show_hitboxes
            if self.state == GameState.PLAYING:
                self.update_playing(dt, pygame.key.get_pressed())
            self.draw()

if __name__ == "__main__":
    try:
        Game().run()
    except FileNotFoundError as error:
        print(error)
        pygame.quit()